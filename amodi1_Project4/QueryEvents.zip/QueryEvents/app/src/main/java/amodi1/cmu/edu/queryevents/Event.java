package amodi1.cmu.edu.queryevents;

/**
 * Created by ankur on 11/11/2017.
 */

public class Event {
        public String title;
        public String address;
        public String time;

}
